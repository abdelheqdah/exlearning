import { useEffect, useState } from 'react'
import type { ProgressState } from '../types'
import { initialProgress, normaliseProgress, recordQuizResult, recordScenarioResult, resetProgress, storageKey } from '../utils/progress'

function loadProgress(): ProgressState {
  try {
    const raw = localStorage.getItem(storageKey)
    if (!raw) return initialProgress
    return normaliseProgress(JSON.parse(raw))
  } catch {
    return initialProgress
  }
}

export function useProgress() {
  const [progress, setProgress] = useState<ProgressState>(loadProgress)

  useEffect(() => {
    localStorage.setItem(storageKey, JSON.stringify(progress))
  }, [progress])

  const startLesson = (id: string) => setProgress((current) => ({ ...current, startedLessons: [...new Set([...current.startedLessons, id])] }))
  const completeLesson = (id: string) => setProgress((current) => ({ ...current, startedLessons: [...new Set([...current.startedLessons, id])], completedLessons: [...new Set([...current.completedLessons, id])] }))
  const saveQuizScore = (id: string, score: number) => setProgress((current) => recordQuizResult(current, id, score))
  const recordScenario = (id: string, isCorrect: boolean) => setProgress((current) => recordScenarioResult(current, id, isCorrect))

  const clearProgress = () => setProgress(resetProgress())
  return { progress, startLesson, completeLesson, saveQuizScore, recordScenario, clearProgress }
}
