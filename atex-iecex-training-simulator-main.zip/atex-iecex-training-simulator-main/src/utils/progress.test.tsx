// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import App, { resolveRoute } from '../App'
import { calculateCurriculumProgress, getLessonStatus, getRecommendedPath, initialProgress, normaliseProgress, recordQuizResult, recordScenarioResult, resetProgress, scoreQuiz, storageKey } from './progress'
import { lessons } from '../data/lessons'

afterEach(() => cleanup())

describe('route rendering', () => {
  beforeEach(() => {
    window.history.pushState({}, '', '/')
    localStorage.clear()
  })

  it('renders the home page', () => {
    render(<App />)
    expect(screen.getByRole('heading', { name: /build better decisions/i })).toBeTruthy()
  })

  it('renders the fallback page for an unknown route', () => {
    window.history.pushState({}, '', '/does-not-exist')
    render(<App />)
    expect(screen.getByRole('heading', { name: /learning item is unavailable/i })).toBeTruthy()
  })

  it('resolves known detail routes and an unknown route', () => {
    expect(resolveRoute('/lesson/ex001-foundations')).toEqual({ page: 'lesson', id: 'ex001-foundations' })
    expect(resolveRoute('/unknown/path')).toEqual({ page: 'not-found', id: 'path' })
  })
})

describe('learning outcomes', () => {
  it('calculates quiz scores and preserves the best score after a retry', () => {
    expect(scoreQuiz(2, 3)).toBe(67)
    const attempted = recordQuizResult(initialProgress, 'quiz-1', 50)
    expect(attempted.attemptedQuizzes).toContain('quiz-1')
    expect(attempted.completedQuizzes).not.toContain('quiz-1')
    const completed = recordQuizResult(attempted, 'quiz-1', 100)
    expect(completed.completedQuizzes).toContain('quiz-1')
    expect(recordQuizResult(completed, 'quiz-1', 50).quizScores['quiz-1']).toBe(100)
    expect(recordQuizResult(completed, 'quiz-1', 50).quizAttempts['quiz-1']).toBe(3)
  })

  it('records scenario attempts separately from successful completion', () => {
    const attempted = recordScenarioResult(initialProgress, 'scenario-1', false)
    expect(attempted.attemptedScenarios).toContain('scenario-1')
    expect(attempted.completedScenarios).not.toContain('scenario-1')
    expect(recordScenarioResult(attempted, 'scenario-1', true).completedScenarios).toContain('scenario-1')
    expect(recordScenarioResult(attempted, 'scenario-1', true).scenarioAttempts['scenario-1']).toBe(2)
  })
})

describe('localStorage persistence', () => {
  it('normalises and restores stored progress', () => {
    localStorage.setItem(storageKey, JSON.stringify({ completedLessons: ['lesson-1'], attemptedQuizzes: ['quiz-1'] }))
    const restored = normaliseProgress(JSON.parse(localStorage.getItem(storageKey)!))
    expect(restored.completedLessons).toEqual(['lesson-1'])
    expect(restored.attemptedQuizzes).toEqual(['quiz-1'])
    expect(restored.completedScenarios).toEqual([])
    expect(restored.startedLessons).toEqual(['lesson-1'])
  })
})

describe('curriculum progression', () => {
  it('calculates lesson status, module progress, and level progress', () => {
    const progress = { ...initialProgress, startedLessons: [lessons[0].id, lessons[1].id], completedLessons: [lessons[0].id] }
    const summary = calculateCurriculumProgress(progress, lessons)
    expect(getLessonStatus(progress, lessons[0].id)).toBe('completed')
    expect(getLessonStatus(progress, lessons[1].id)).toBe('in-progress')
    expect(summary.completedLessons).toBe(1)
    expect(summary.inProgressLessons).toBe(1)
    expect(summary.byModule[lessons[0].moduleOrder].completed).toBe(1)
    expect(summary.byLevel.Beginner.total).toBeGreaterThan(0)
  })

  it('keeps reset state empty and compatible with the stored shape', () => {
    const reset = resetProgress()
    expect(reset.startedLessons).toEqual([])
    expect(reset.quizScores).toEqual({})
    expect(reset.completedScenarios).toEqual([])
  })

  it('recommends the next ordered activity for each progress state', () => {
    const lessonIds = ['lesson-a', 'lesson-b']
    const quizIds = ['quiz-a', 'quiz-b']
    const scenarioIds = ['scenario-a', 'scenario-b']
    expect(getRecommendedPath(initialProgress, lessonIds, quizIds, scenarioIds)).toBe('/lesson/lesson-a')
    expect(getRecommendedPath({ ...initialProgress, startedLessons: ['lesson-a'] }, lessonIds, quizIds, scenarioIds)).toBe('/lesson/lesson-a')
    expect(getRecommendedPath({ ...initialProgress, completedLessons: ['lesson-a'] }, lessonIds, quizIds, scenarioIds)).toBe('/lesson/lesson-b')
    expect(getRecommendedPath({ ...initialProgress, completedLessons: lessonIds, completedQuizzes: ['quiz-a'] }, lessonIds, quizIds, scenarioIds)).toBe('/quiz/quiz-b')
    expect(getRecommendedPath({ ...initialProgress, completedLessons: lessonIds, completedQuizzes: quizIds, completedScenarios: ['scenario-a'] }, lessonIds, quizIds, scenarioIds)).toBe('/scenario/scenario-b')
    expect(getRecommendedPath({ ...initialProgress, completedLessons: lessonIds, completedQuizzes: quizIds, completedScenarios: scenarioIds }, lessonIds, quizIds, scenarioIds)).toBe('/scenarios')
  })

  it('handles empty curricula and unknown progress IDs without invalid percentages', () => {
    const progress = { ...initialProgress, startedLessons: ['missing'], completedLessons: ['missing'] }
    const summary = calculateCurriculumProgress(progress, [])
    expect(summary.totalLessons).toBe(0)
    expect(summary.completionPercent).toBe(0)
    expect(summary.byModule).toEqual({})
    expect(Object.values(summary.byLevel).every((level) => level.percent === 0 && level.notStarted === 0)).toBe(true)
    expect(calculateCurriculumProgress(progress, lessons).completedLessons).toBe(0)
  })
})

describe('progress UI', () => {
  it('marks only the opened lesson in progress and preserves completed lessons', async () => {
    const completedId = lessons[0].id
    const openedId = lessons[1].id
    localStorage.setItem(storageKey, JSON.stringify({ completedLessons: [completedId] }))
    window.history.pushState({}, '', `/lesson/${openedId}`)
    render(<App />)
    await waitFor(() => expect(normaliseProgress(JSON.parse(localStorage.getItem(storageKey)!)).startedLessons).toEqual([completedId, openedId]))
    expect(normaliseProgress(JSON.parse(localStorage.getItem(storageKey)!)).completedLessons).toEqual([completedId])
  })

  it('navigates to the previous and next ordered modules', () => {
    window.history.pushState({}, '', `/lesson/${lessons[1].id}`)
    render(<App />)
    fireEvent.click(screen.getByRole('button', { name: /previous module/i }))
    expect(screen.getByRole('heading', { name: lessons[0].title })).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: /next module/i }))
    expect(screen.getByRole('heading', { name: lessons[1].title })).toBeTruthy()
  })

  it('clears local progress only after reset confirmation', async () => {
    localStorage.setItem(storageKey, JSON.stringify({ completedLessons: [lessons[0].id] }))
    window.history.pushState({}, '', '/progress')
    const confirm = vi.spyOn(window, 'confirm').mockReturnValue(false)
    const view = render(<App />)
    fireEvent.click(screen.getByRole('button', { name: /reset local progress/i }))
    expect(confirm).toHaveBeenCalled()
    expect(JSON.parse(localStorage.getItem(storageKey)!)).toMatchObject({ completedLessons: [lessons[0].id] })
    view.unmount()

    confirm.mockReturnValue(true)
    render(<App />)
    fireEvent.click(screen.getByRole('button', { name: /reset local progress/i }))
    await waitFor(() => expect(normaliseProgress(JSON.parse(localStorage.getItem(storageKey)!))).toEqual(initialProgress))
    confirm.mockRestore()
  })

  it('renders an empty assessment summary and a populated accessible summary', async () => {
    window.history.pushState({}, '', '/progress')
    const emptyView = render(<App />)
    expect(screen.getByRole('heading', { name: /your practice record/i })).toBeTruthy()
    expect(screen.getByText(/no quiz or scenario attempts yet/i)).toBeTruthy()
    emptyView.unmount()

    localStorage.setItem(storageKey, JSON.stringify({
      attemptedQuizzes: ['orientation-boundaries'],
      completedQuizzes: ['orientation-boundaries'],
      quizScores: { 'orientation-boundaries': 100 },
      quizAttempts: { 'orientation-boundaries': 2 },
      attemptedScenarios: ['unclear-area-drawing'],
      scenarioAttempts: { 'unclear-area-drawing': 1 },
    }))
    render(<App />)
    await waitFor(() => expect(screen.getByRole('table')).toBeTruthy())
    expect(screen.getByRole('cell', { name: /best 100%/i })).toBeTruthy()
    expect(screen.getByText(/ex scope and boundaries/i)).toBeTruthy()
    expect(screen.getByText(/an unclear area drawing/i)).toBeTruthy()
    expect(screen.getByText(/not certification, approval, compliance evidence/i)).toBeTruthy()
  })

  it('renders missing lesson and quiz references safely', () => {
    window.history.pushState({}, '', '/lesson/missing-lesson')
    const lessonView = render(<App />)
    expect(screen.getByRole('heading', { name: /learning item is unavailable/i })).toBeTruthy()
    lessonView.unmount()
    window.history.pushState({}, '', '/quiz/missing-quiz')
    render(<App />)
    expect(screen.getByRole('heading', { name: /learning item is unavailable/i })).toBeTruthy()
  })

  it('exposes the primary navigation and skip link for keyboard users', () => {
    window.history.pushState({}, '', '/')
    render(<App />)
    expect(screen.getByRole('navigation', { name: /primary navigation/i })).toBeTruthy()
    expect(screen.getByRole('link', { name: /skip to main content/i }).getAttribute('href')).toBe('#main-content')
    expect(screen.getByRole('main').getAttribute('tabindex')).toBe('-1')
  })
})
