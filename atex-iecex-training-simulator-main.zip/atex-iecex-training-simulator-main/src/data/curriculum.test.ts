import { describe, expect, it } from 'vitest'
import { lessons } from './lessons'
import { quizzes } from './quizzes'
import { scenarios } from './scenarios'
import { normaliseProgress } from '../utils/progress'
import { validateCurriculumIntegrity } from '../utils/integrity'

describe('Phase 2 curriculum integrity', () => {
  it('keeps stable, ordered lesson references', () => {
    expect(lessons.length).toBeGreaterThanOrEqual(20)
    expect(new Set(lessons.map((lesson) => lesson.id)).size).toBe(lessons.length)
    expect(lessons.map((lesson) => lesson.moduleOrder)).toEqual([...lessons].sort((a, b) => a.moduleOrder - b.moduleOrder).map((lesson) => lesson.moduleOrder))
    for (const lesson of lessons) {
      for (const prerequisite of lesson.prerequisites) expect(lessons.some((item) => item.id === prerequisite)).toBe(true)
    }
  })

  it('keeps quiz and scenario lesson relationships valid', () => {
    expect(quizzes.reduce((total, quiz) => total + quiz.questions.length, 0)).toBeGreaterThanOrEqual(100)
    expect(scenarios.length).toBeGreaterThanOrEqual(12)
    const lessonIds = new Set(lessons.map((lesson) => lesson.id))
    expect(new Set(quizzes.map((quiz) => quiz.id)).size).toBe(quizzes.length)
    expect(new Set(scenarios.map((scenario) => scenario.id)).size).toBe(scenarios.length)
    for (const quiz of quizzes) {
      expect(quiz.lessonIds.every((id) => lessonIds.has(id))).toBe(true)
      expect(quiz.questions.every((question) => lessonIds.has(question.relatedLessonId))).toBe(true)
    }
    for (const scenario of scenarios) expect(scenario.lessonIds.every((id) => lessonIds.has(id))).toBe(true)
  })

  it('passes complete assessment integrity validation', () => {
    expect(validateCurriculumIntegrity(lessons, quizzes, scenarios)).toEqual([])
  })

  it('provides Phase 6 applied content and educational metadata', () => {
    const phase6Ids = ['ex007-installation-practice', 'ex-d-flameproof', 'ex-e-increased-safety', 'ex-i-intrinsic-safety', 'ex-t-dust-protection', 'ex-p-pressurization', 'glands-and-cable-entries', 'marking-findings-and-is-calculations']
    for (const id of phase6Ids) {
      const lesson = lessons.find((item) => item.id === id)
      expect(lesson?.checklist?.length).toBeGreaterThanOrEqual(3)
      expect(lesson?.examples?.length).toBeGreaterThanOrEqual(1)
    }
    const phase6Questions = quizzes.flatMap((quiz) => quiz.questions).filter((question) => question.trainingData?.educationalOnly)
    expect(phase6Questions.length).toBeGreaterThanOrEqual(80)
    expect(phase6Questions.some((question) => question.kind === 'calculation')).toBe(true)
    expect(phase6Questions.some((question) => question.kind === 'finding')).toBe(true)
  })

  it('meets the focused EX001, EX007, and EX008 assessment distribution', () => {
    const questions = quizzes.flatMap((quiz) => quiz.questions)
    const countForLesson = (lessonId: string) => questions.filter((question) => question.relatedLessonId === lessonId).length
    expect(countForLesson('ex001-foundations')).toBeGreaterThanOrEqual(30)
    expect(countForLesson('ex007-installation-practice')).toBeGreaterThanOrEqual(25)
    expect(countForLesson('ex008-inspection')).toBeGreaterThanOrEqual(30)
  })

  it('detects invalid answer indexes, duplicate IDs, and missing references', () => {
    const invalidQuiz = { ...quizzes[0], id: quizzes[1].id, lessonIds: ['missing-lesson'], questions: [{ ...quizzes[0].questions[0], id: quizzes[0].questions[1].id, correctAnswer: 99, relatedLessonId: 'missing-lesson' }] }
    const invalidScenario = { ...scenarios[0], correctChoice: 99, lessonIds: ['missing-lesson'] }
    const issues = validateCurriculumIntegrity(lessons, [invalidQuiz], [invalidScenario])
    expect(issues.some((issue) => issue.type === 'answer-index')).toBe(true)
    expect(issues.some((issue) => issue.type === 'scenario-choice')).toBe(true)
    expect(issues.some((issue) => issue.type === 'quiz-reference')).toBe(true)
    expect(issues.some((issue) => issue.type === 'question-reference')).toBe(true)
    expect(issues.some((issue) => issue.type === 'scenario-reference')).toBe(true)
  })

  it('preserves legacy progress fields while adding Phase 2 fields', () => {
    const progress = normaliseProgress({ completedLessons: ['ex001-foundations'], quizScores: { 'foundations-check': 100 } })
    expect(progress.completedLessons).toEqual(['ex001-foundations'])
    expect(progress.quizScores['foundations-check']).toBe(100)
    expect(progress.attemptedQuizzes).toEqual([])
    expect(progress.completedScenarios).toEqual([])
  })

  it('states the CoPC, RTP, and ExCB boundary explicitly', () => {
    const boundary = lessons.find((lesson) => lesson.id === 'copc-rtp-excb')
    const text = boundary?.sections.map((section) => section.body).join(' ') ?? ''
    expect(text).toMatch(/not an RTP/i)
    expect(text).toMatch(/not an ExCB/i)
    expect(text).toMatch(/does not issue CoPC/i)
  })
})
