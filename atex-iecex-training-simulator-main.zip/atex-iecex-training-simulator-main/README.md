# ExLearn — ATEX & IECEx Training Simulator

An independent, educational browser application for learning ATEX and IECEx-related concepts, practising quizzes, and working through hazardous-area decision scenarios.

## Run locally

```bash
npm install
npm run dev
```

Use `npm run lint`, `npm test`, and `npm run build` to check the project.

When deploying this client-side app, configure the host to serve `index.html` as the fallback for unknown paths. This is required so direct visits or refreshes on routes such as `/lessons` and `/lesson/ex001-foundations` are handled by the app router instead of returning a server 404.

## Learning progress

Lesson, quiz, and scenario progress is stored only in the current browser's local storage. The Progress page shows ordered module completion, level summaries, activity attempts, and a Continue learning recommendation. Use Reset local progress to clear this browser's saved state. Existing progress data from earlier application versions remains readable.

## Scope and safety

ExLearn is for general educational use only. It is not official IECEx or IEC training, certification, approval, legal advice, or a substitute for current standards, manufacturer instructions, local regulations, site procedures, or competent professional judgment. Progress is stored only in the browser's local storage; there is no login, backend, database, or payment flow.

## Curriculum and assessment bank

The 24 ordered lessons progress from Ex fundamentals and ATEX/IECEx context through hazardous atmospheres, gas/vapour/mist/dust hazards, zones, Equipment Protection Levels, Ex d, Ex e, Ex i, Ex t, Ex p, equipment marking, installation, inspection, maintenance, repair, documentation, competence, and integrated decisions. Phase 6 adds focused EX001 foundations, EX007 installation practice, EX008 inspection, cable-entry, protection-concept, marking, findings, and intrinsic-safety calculation lessons.

The assessment bank contains 193 original questions, including at least 30 questions directly related to EX001 foundations, 25 related to EX007 installation practice, and 30 related to EX008 inspection. Questions are educational exercises with explanations; results do not certify personnel or approve equipment, installations, or compliance.

The application includes educational explanations of CoPC, RTP, and ExCB roles. ExLearn is not an RTP, is not an ExCB, and does not issue CoPC. No lesson, quiz, scenario, or progress result is a certification, approval, or legal-compliance decision.

Terminology was checked against official IECEx system information and IEC publication metadata before writing original content:

- [IECEx](https://www.iecex.com/)
- [IEC Webstore](https://webstore.iec.ch/)
- [IEC 60079 series publication search](https://webstore.iec.ch/en/search?query=60079)
